USE "Customers"

GO


IF OBJECT_ID('Report','U') IS NOT NULL
BEGIN
	DROP TABLE "Report"
END

CREATE TABLE "Report"
(
"Id" INTEGER NOT NULL IDENTITY PRIMARY KEY,
"ClientId" INTEGER,
"BankCode" VARCHAR(11),
"CorrAccount" VARCHAR(28),
"Number" VARCHAR(10),
"Debit" DECIMAL(15, 2),
"Credit" DECIMAL(15, 2),
"Equivalent" DECIMAL(15, 2),
"date" DATE,
"Purpose" VARCHAR(500),
"NameCompany" VARCHAR(100),
"UNP" VARCHAR(9)
);

GO


INSERT INTO "Report"("ClientId","BankCode","CorrAccount","Number","Debit","Credit","Equivalent","Date","Purpose","NameCompany","UNP")
VALUES
(41,'00000000000','0000000000000000000000000000','2',134.17,0,134.17,'2020-04-21','Parturient finibus lectus vehicula nisl blandit dignissim eleifend tristique  ','Duis pretium augue','000000222'),
(50,'00000000000','0000000000000000000000000000','323',0,133.00,133.00,'2020-04-21','habitant fermentum torquent a curae adipiscing sed congue  suspendisse facilisis  himenaeos mi consectetur magnis dis  Auctor','Proin nibh morbi','000000249'),
(69,'00000000000','0000000000000000000000000000','738',0,25.00,25.00,'2020-04-23','conubia bibendum varius sollicitudin  magna fermentum quis semper imperdiet  sodales venenatis commodo nulla hac mollis','Accumsan rhoncus lobortis','000000306'),
(53,'00000000000','0000000000000000000000000000','3195',0,427.00,427.00,'2020-04-24',' justo ac dictum  laoreet vel mattis nisl ut a et sed  Amet ipsum tempus','Malesuada imperdiet lorem','000000258'),
(98,'00000000000','0000000000000000000000000000','11',640.00,0,640.00,'2020-04-29','non vestibulum  suscipit consectetur massa enim  imperdiet vulputate eget risus viverra feugiat dictum urna id','Adipiscing  elit','000000393'),
(20,'00000000000','0000000000000000000000000000','5966859',12.16,0,12.16,'2020-04-29','  torquent turpis orci phasellus porttitor justo elit  Himenaeos semper condimentum lorem fusce consectetur  turpis massa phasellus potenti','Rutrum aliquam per','000000159'),
(153,'00000000000','0000000000000000000000000000','805',0,246.00,246.00,'2020-04-30','maecenas lorem iaculis sapien mi at platea placerat hac  consectetur ornare cubilia fames rhoncus ','Parturient etiam fusce','000000558'),
(147,'00000000000','0000000000000000000000000000','3623',0,283.00,283.00,'2020-04-30','a nisi platea cursus pretium parturient   lacus fermentum','Tristique nullam nibh','000000540'),
(152,'00000000000','0000000000000000000000000000','115',0,24.00,24.00,'2020-04-30','orci nam mus nisl at odio facilisis bibendum  mattis ad phasellus taciti maecenas justo enim vestibulum   Nulla erat ac aenean','Facilisi  maecenas','000000555'),
(57,'00000000000','0000000000000000000000000000','6024509',2.50,0,2.50,'2020-04-30','non ad praesent ultricies vulputate quisque montes  malesuada primis eleifend  ut elit commodo parturient etiam vel','Accumsan inceptos nascetur','000000270'),
(41,'00000000000','0000000000000000000000000000','5997739',0,0.09,0.09,'2020-04-30','rutrum aliquam per scelerisque nulla dapibus  Aptent facilisi placerat ex  feugiat at  elit himenaeos luctus mollis  Quam purus leo himenaeos','Duis pretium augue','000000222'),
(7,'00000000000','0000000000000000000000000000','350',0,25.00,25.00,'2020-05-04',' mauris primis suspendisse eget tincidunt  Odio vehicula malesuada dis massa at risus phasellus','Semper imperdiet ','000000120'),
(144,'00000000000','0000000000000000000000000000','6086426',10.00,0,10.00,'2020-05-07','non sem  ligula sociosqu amet fames cubilia mollis per   Inceptos nulla maecenas curae libero ante natoque cursus','Ornare vestibulum feugiat','000000531'),
(58,'00000000000','0000000000000000000000000000','20006050',0,38.00,38.00,'2020-05-11',' purus ultrices duis turpis facilisi nunc vel   quisque sociosqu eget blandit cubilia parturient  Eleifend dictumst cursus fringilla congue mi','Consequat arcu sem','000000273'),
(102,'00000000000','0000000000000000000000000000','103',0,36.00,36.00,'2020-05-13','donec elementum  taciti malesuada  bibendum nisl lacinia duis pretium augue dictum','Natoque nibh leo','000000405'),
(131,'00000000000','0000000000000000000000000000','101',0,36.00,36.00,'2020-05-19','consectetur tempor cubilia  ante amet dapibus  habitant pellentesque iaculis blandit','Dapibus morbi pellentesque','000000492'),
(9,'00000000000','0000000000000000000000000000','57',0,12.00,12.00,'2020-05-22','et  Eleifend duis litora placerat netus etiam suscipit aliquet mi aliquam   magnis leo dui augue natoque','Laoreet vel mattis','000000126'),
(80,'00000000000','0000000000000000000000000000','6246010',0,0.26,0.26,'2020-05-29','facilisi elit  hendrerit  Bibendum iaculis dapibus odio magnis sociosqu proin nibh morbi posuere nulla integer cursus nunc  ','Litora magnis ornare','000000339'),
(112,'00000000000','0000000000000000000000000000','6279732',2.50,0,2.50,'2020-05-29','sagittis primis ad magna euismod  neque venenatis porta nostra ultricies','Suscipit augue luctus','000000435'),
(166,'00000000000','0000000000000000000000000000','906',0,205.00,205.00,'2020-06-02','montes molestie accumsan sed dictumst dolor nec maecenas suspendisse malesuada imperdiet lorem ','Inceptos  interdum','000000597'),
(140,'00000000000','0000000000000000000000000000','435',0,134.00,134.00,'2020-06-03','non conubia  consequat torquent ex sem mollis pulvinar lobortis','Litora lacus ','000000519'),
(37,'00000000000','0000000000000000000000000000','6329124',10.00,0,10.00,'2020-06-04','lacus tellus mauris  Integer diam per cubilia risus class  nunc consectetur accumsan inceptos','Turpis facilisi nunc','000000210'),
(86,'00000000000','0000000000000000000000000000','12',996.00,0,996.00,'2020-06-05','nascetur  platea maximus taciti consequat arcu sem turpis himenaeos odio ac   velit eleifend potenti habitant semper cursus dictumst bibendum','Sagittis dignissim ','000000357'),
(138,'00000000000','0000000000000000000000000000','6346855',18.92,0,18.92,'2020-06-05','placerat  Tellus tempor semper pretium morbi  blandit adipiscing facilisi risus lacus  id a eros','Proin  curae','000000513'),
(165,'00000000000','0000000000000000000000000000','151',0,36.00,36.00,'2020-06-16','rutrum magna vestibulum pulvinar quam  aliquam natoque torquent  proin dis vel platea ultrices  Suscipit elit','Varius praesent ','000000594'),
(43,'00000000000','0000000000000000000000000000','6052',0,66.00,66.00,'2020-06-19','magnis amet sapien quam phasellus venenatis volutpat  ac taciti egestas','Habitant pellentesque iaculis','000000228'),
(45,'00000000000','0000000000000000000000000000','379',0,25.00,25.00,'2020-06-22','consequat semper ornare   Nec ut venenatis accumsan rhoncus lobortis tellus tincidunt pellentesque  nostra commodo dis eu cubilia tempus ','Suscipit aliquet mi','000000234'),
(7,'00000000000','0000000000000000000000000000','157',0,36.00,36.00,'2020-06-23','interdum  Cursus phasellus nascetur leo pretium consectetur porta parturient  pulvinar ad lacus lacinia vivamus  elementum ullamcorper  etiam dictumst','Semper imperdiet ','000000120'),
(6,'00000000000','0000000000000000000000000000','5030',0,352.00,352.00,'2020-06-24','elit rhoncus nullam netus  Convallis morbi tellus aenean ut justo imperdiet  conubia orci  consequat pellentesque nisi ornare natoque iaculis accumsan finibus','Varius sollicitudin ','000000117'),
(30,'00000000000','0000000000000000000000000000','6487192',0,0.11,0.11,'2020-06-30',' eget sed inceptos volutpat  quisque eros molestie scelerisque blandit  sagittis porttitor euismod','Consectetur ornare cubilia','000000189'),
(130,'00000000000','0000000000000000000000000000','6531512',2.50,0,2.50,'2020-06-30','primis  habitant odio quam fusce  lacinia torquent faucibus  Nam odio porta litora magnis ornare pulvinar libero fusce','Non nostra quam','000000489'),
(150,'00000000000','0000000000000000000000000000','6583223',10.00,0,10.00,'2020-07-07','sapien pretium morbi lobortis  Erat vitae  tempor faucibus vestibulum efficitur netus sapien fames','Eros inceptos dapibus','000000549'),
(124,'00000000000','0000000000000000000000000000','3',117.57,0,117.57,'2020-07-07','inceptos rhoncus conubia  ridiculus leo sagittis dignissim  ad risus venenatis hendrerit sollicitudin iaculis  nibh pellentesque sociosqu bibendum viverra auctor in','Suspendisse at donec','000000471'),
(124,'00000000000','0000000000000000000000000000','13',378.00,0,378.00,'2020-07-07','amet diam  habitasse  Dui euismod vitae mi condimentum netus ut nostra curae lacus  risus eleifend etiam auctor','Suspendisse at donec','000000471'),
(148,'00000000000','0000000000000000000000000000','6587558',7.18,0,7.18,'2020-07-07','diam nunc  bibendum curabitur purus et  ipsum arcu cursus integer','Enim nisl scelerisque','000000543'),
(76,'00000000000','0000000000000000000000000000','322',0,52.00,52.00,'2020-07-10','malesuada mauris finibus lorem  Laoreet eu sodales non  imperdiet','Imperdiet  conubia','000000327'),
(2,'00000000000','0000000000000000000000000000','1298',0,181.00,181.00,'2020-07-10','mi massa condimentum risus molestie  neque dui per elit convallis nascetur eleifend  Lorem ipsum dolor sit amet consectetur','Dignissim eleifend tristique','000000105'),
(7,'00000000000','0000000000000000000000000000','1220',0,60.00,60.00,'2020-07-13','adipiscing  elit ultricies facilisi nibh sagittis leo  orci id volutpat rutrum  sollicitudin  Cursus imperdiet porta hac fermentum id risus','Semper imperdiet ','000000120'),
(33,'00000000000','0000000000000000000000000000','1249',0,12.00,12.00,'2020-07-14','primis suscipit natoque nibh leo  sodales litora sit morbi  ad libero per hendrerit porttitor quam tellus dignissim ','Risus phasellus non','000000198'),
(140,'00000000000','0000000000000000000000000000','6663',0,207.00,207.00,'2020-07-17','laoreet aptent lorem luctus blandit proin integer rhoncus  lacus','Litora lacus ','000000519'),
(154,'00000000000','0000000000000000000000000000','319641',0,12.00,12.00,'2020-07-21','etiam auctor adipiscing purus per magnis posuere  Et varius','Rutrum proin malesuada','000000561'),
(147,'00000000000','0000000000000000000000000000','571',0,176.00,176.00,'2020-07-21','pharetra  Lacus inceptos dolor consequat tellus eu dui pellentesque class  taciti convallis aliquam magna fusce  tempor suscipit arcu ','Tristique nullam nibh','000000540'),
(162,'00000000000','0000000000000000000000000000','14',685.00,0,685.00,'2020-07-24','tempus viverra efficitur lectus odio  suscipit augue luctus sapien sodales id mollis  venenatis ligula sed commodo ridiculus dictumst','Convallis molestie lacus','000000585'),
(154,'00000000000','0000000000000000000000000000','6707510',13.02,0,13.02,'2020-07-24',' Class adipiscing  ullamcorper taciti arcu hac augue eros auctor phasellus scelerisque','Rutrum proin malesuada','000000561'),
(99,'00000000000','0000000000000000000000000000','151',0,24.00,24.00,'2020-07-27','imperdiet maximus  ipsum netus fermentum magnis  vestibulum ad erat et ultrices turpis  Magna sociosqu facilisis laoreet metus euismod natoque','Sagittis leo ','000000396'),
(6,'00000000000','0000000000000000000000000000','192',0,24.00,24.00,'2020-07-30',' odio ornare leo rutrum  tincidunt  tristique libero netus tellus velit  Efficitur augue tempus phasellus','Varius sollicitudin ','000000117'),
(1,'00000000000','0000000000000000000000000000','159',0,24.00,24.00,'2020-07-30','sodales amet aenean commodo erat scelerisque  in habitasse suspendisse at donec  vehicula','Parturient finibus lectus','000000102'),
(5,'00000000000','0000000000000000000000000000','6797713',2.50,0,2.50,'2020-07-31','sociosqu praesent potenti  vel dignissim bibendum ornare curabitur facilisi quis lorem  Vivamus curae ','Magnis dis ','000000114'),
(24,'00000000000','0000000000000000000000000000','6766314',0,0.14,0.14,'2020-07-31','imperdiet nisl sed maecenas sit cursus nunc aenean at  conubia taciti ut risus nascetur class primis facilisis amet   Non','Pretium parturient ','000000171'),
(103,'00000000000','0000000000000000000000000000','7308',0,237.00,237.00,'2020-07-31','nostra quam magna accumsan habitasse dapibus morbi pellentesque  mollis orci tincidunt senectus libero lorem  praesent ultrices','Morbi  ad','000000408'),
(9,'00000000000','0000000000000000000000000000','6782',0,33.00,33.00,'2020-07-31','nam  adipiscing ridiculus lobortis suspendisse eleifend facilisi vestibulum  Semper','Laoreet vel mattis','000000126'),
(99,'00000000000','0000000000000000000000000000','6865663',10.00,0,10.00,'2020-08-06','augue faucibus  posuere dictumst sem facilisi aenean pellentesque quis blandit  cras scelerisque sollicitudin vel porttitor laoreet  cubilia luctus sociosqu','Sagittis leo ','000000396'),
(17,'00000000000','0000000000000000000000000000','284',0,100.00,100.00,'2020-08-25','proin  curae inceptos est vestibulum praesent fusce parturient cursus integer ','Potenti non ad','000000150'),
(14,'00000000000','0000000000000000000000000000','15',490.00,0,490.00,'2020-08-26','Litora lacus  interdum euismod etiam ut nam quisque vitae  dictum id est conubia laoreet nibh parturient','Torquent turpis orci','000000141'),
(134,'00000000000','0000000000000000000000000000','6988982',9.31,0,9.31,'2020-08-26','lorem metus  enim sed  sagittis convallis ornare vestibulum feugiat ','Vestibulum  semper','000000501'),
(105,'00000000000','0000000000000000000000000000','218',0,70.00,70.00,'2020-08-26','Ut ornare cursus vestibulum facilisis dictum lectus vel ridiculus mus  sit per diam ','Lorem luctus blandit','000000414'),
(18,'00000000000','0000000000000000000000000000','1291',0,14.00,14.00,'2020-08-28','tristique nullam nibh at litora rhoncus enim nisl scelerisque habitasse  Orci vel sollicitudin sem  commodo eleifend sed eros','Quisque montes ','000000153'),
(137,'00000000000','0000000000000000000000000000','7052113',2.50,0,2.50,'2020-08-31','inceptos dapibus vehicula sapien  mauris laoreet rhoncus elementum duis class facilisi  maecenas','Vel porttitor laoreet','000000510'),
(78,'00000000000','0000000000000000000000000000','7029512',0,0.12,0.12,'2020-08-31','habitant  Quam lacinia parturient etiam fusce eget egestas risus rutrum proin malesuada ad  aenean id  fermentum sodales nisl donec','Primis  habitant','000000333'),
(65,'00000000000','0000000000000000000000000000','8865',0,43.00,43.00,'2020-08-31','porttitor luctus non  Cras euismod dis himenaeos blandit cubilia','Proin dis vel','000000294'),
(1,'00000000000','0000000000000000000000000000','13672',0,234.00,234.00,'2020-09-02','netus ipsum nisi  turpis vehicula lacus  auctor proin placerat hac sapien duis facilisi accumsan integer massa','Parturient finibus lectus','000000102'),
(21,'00000000000','0000000000000000000000000000','7122156',10.00,0,10.00,'2020-09-04',' litora ullamcorper  vulputate senectus molestie ac tellus urna','Aptent facilisi placerat','000000162'),
(24,'00000000000','0000000000000000000000000000','17',275.00,0,275.00,'2020-09-11','erat enim  Convallis molestie lacus vehicula netus pharetra hendrerit  lacinia tincidunt mauris  vel volutpat himenaeos sagittis porttitor bibendum varius praesent','Pretium parturient ','000000171'),
(16,'00000000000','0000000000000000000000000000','7176804',5.23,0,5.23,'2020-09-11',' et massa cras inceptos  interdum maecenas egestas eleifend  Justo feugiat elit cursus diam proin leo curabitur ligula','Fusce consectetur ','000000147'),
(114,'00000000000','0000000000000000000000000000','1034',0,159.00,159.00,'2020-09-18','lectus curae  fames  maximus libero sollicitudin ac a hendrerit massa pellentesque mollis vehicula  parturient posuere','Ridiculus dictumst ','000000441'),
(102,'00000000000','0000000000000000000000000000','9570',0,97.00,97.00,'2020-09-25','Vitae venenatis amet himenaeos vel magna orci  eget cras conubia natoque tempor  ullamcorper','Natoque nibh leo','000000405'),
(159,'00000000000','0000000000000000000000000000','2275',0,12.00,12.00,'2020-09-25','Lorem consectetur sagittis justo feugiat nunc hendrerit inceptos non volutpat quam  nisl in egestas porta  dolor imperdiet vel facilisi ','Hac sapien duis','000000576'),
(46,'00000000000','0000000000000000000000000000','319',0,35.00,35.00,'2020-09-25','penatibus molestie nisi neque pulvinar purus porta laoreet  cursus ','Dui augue natoque','000000237'),
(68,'00000000000','0000000000000000000000000000','9584',0,204.00,204.00,'2020-09-25','laoreet  dignissim sit sagittis platea per  Iaculis efficitur pretium nulla per sed himenaeos id','Consequat semper ornare','000000303'),
(10,'00000000000','0000000000000000000000000000','7252423',10.45,0,10.45,'2020-09-25','tempor mus  bibendum efficitur  finibus interdum nec id  nulla rutrum','Et sed ','000000129'),
(122,'00000000000','0000000000000000000000000000','18',550.00,0,550.00,'2020-09-25','facilisis metus  donec per non consectetur volutpat Platea luctus sodales phasellus maecenas fermentum','Efficitur augue tempus','000000465'),
(2,'00000000000','0000000000000000000000000000','119',0,56.00,56.00,'2020-09-25','molestie dis dapibus venenatis  Quam potenti etiam sem rutrum vitae consectetur  montes fermentum pharetra placerat pretium leo  hendrerit','Dignissim eleifend tristique','000000105'),
(36,'00000000000','0000000000000000000000000000','1896',0,195.00,195.00,'2020-09-29',' rhoncus et  nullam ornare velit natoque purus congue primis penatibus pharetra  sit porttitor aliquet morbi  massa','Natoque cursus ','000000207'),
(72,'00000000000','0000000000000000000000000000','203',0,24.00,24.00,'2020-09-29','metus netus sem  A enim habitasse varius aptent hac ligula erat bibendum eleifend','Pretium consectetur porta','000000315'),
(78,'00000000000','0000000000000000000000000000','7303108',2.50,0,2.50,'2020-09-30','sodales lorem auctor  platea  etiam fringilla cras fames integer non tincidunt laoreet in facilisis litora  Mus netus','Primis  habitant','000000333'),
(163,'00000000000','0000000000000000000000000000','7296550',0,0.06,0.06,'2020-09-30','aenean pulvinar  arcu sollicitudin tellus dictum suspendisse  ad lobortis gravida congue sapien','Hendrerit  lacinia','000000588'),
(80,'00000000000','0000000000000000000000000000','746',0,121.00,121.00,'2020-09-30','cursus ullamcorper  per consectetur  blandit penatibus lorem vehicula finibus  Torquent varius placerat felis viverra habitasse','Litora magnis ornare','000000339'),
(97,'00000000000','0000000000000000000000000000','22863',0,59.00,59.00,'2020-10-02','aptent adipiscing accumsan  himenaeos  magnis montes ac dapibus vel eget dignissim sagittis  ad facilisi','Lorem ipsum dolor','000000390'),
(165,'00000000000','0000000000000000000000000000','7399738',10.00,0,10.00,'2020-10-06','et habitant leo odio mollis tempus   Netus hac lectus egestas eleifend per justo nostra  quam','Varius praesent ','000000594'),
(71,'00000000000','0000000000000000000000000000','220',0,73.00,73.00,'2020-10-16',' Auctor conubia bibendum varius sollicitudin  magna fermentum quis semper imperdiet  sodales','Interdum  cursus','000000312'),
(145,'00000000000','0000000000000000000000000000','10367',0,307.00,307.00,'2020-10-16','curae adipiscing sed congue  suspendisse facilisis  himenaeos mi consectetur magnis dis','Vestibulum facilisis dictum','000000534'),
(11,'00000000000','0000000000000000000000000000','7462861',14.35,0,14.35,'2020-10-16','Parturient finibus lectus vehicula nisl blandit dignissim eleifend tristique   habitant fermentum torquent a','Non vestibulum ','000000132'),
(113,'00000000000','0000000000000000000000000000','20',755.00,0,755.00,'2020-10-16','primis leo fringilla ad et quisque  quis arcu mauris  penatibus','Mollis  venenatis','000000438'),
(51,'00000000000','0000000000000000000000000000','805',0,98.00,98.00,'2020-10-20','venenatis commodo nulla hac mollis  justo ac dictum  laoreet vel mattis nisl ut a et sed  Amet ipsum tempus','Cursus nunc ','000000252'),
(118,'00000000000','0000000000000000000000000000','7575085',2.50,0,2.50,'2020-10-30','non vestibulum  suscipit consectetur massa enim  imperdiet vulputate','Erat et ultrices','000000453'),
(8,'00000000000','0000000000000000000000000000','7556530',0,0.10,0.10,'2020-10-30','eget risus viverra feugiat dictum urna id   torquent turpis orci phasellus porttitor justo','Nulla hac mollis','000000123'),
(148,'00000000000','0000000000000000000000000000','11487',0,36.00,36.00,'2020-10-30','elit  Himenaeos semper condimentum lorem fusce consectetur  turpis massa phasellus potenti non ad praesent ultricies vulputate','Enim nisl scelerisque','000000543'),
(72,'00000000000','0000000000000000000000000000','11488',0,12.00,12.00,'2020-10-30','quisque montes  malesuada primis eleifend  ut elit commodo parturient etiam vel rutrum aliquam per scelerisque nulla dapibus','Pretium consectetur porta','000000315'),
(23,'00000000000','0000000000000000000000000000','7648997',10.00,0,10.00,'2020-11-05',' Aptent facilisi placerat ex  feugiat at  elit himenaeos luctus mollis  Quam purus leo himenaeos a nisi','Leo himenaeos a','000000168'),
(82,'00000000000','0000000000000000000000000000','7675299',2.51,0,2.51,'2020-11-09','mattis ad phasellus taciti maecenas justo enim vestibulum   Nulla erat ac aenean maecenas lorem iaculis sapien mi at platea placerat','Molestie scelerisque blandit','000000345'),
(138,'00000000000','0000000000000000000000000000','21',132.00,0,132.00,'2020-11-09','platea cursus pretium parturient   lacus fermentum orci nam mus nisl at odio facilisis bibendum ','Proin  curae','000000513'),
(42,'00000000000','0000000000000000000000000000','22',455.00,0,455.00,'2020-11-16','hac  consectetur ornare cubilia fames rhoncus   mauris primis suspendisse eget tincidunt  Odio vehicula malesuada dis massa at risus phasellus non','Cubilia  ante','000000225'),
(103,'00000000000','0000000000000000000000000000','7715946',8.65,0,8.65,'2020-11-16','sem  ligula sociosqu amet fames cubilia mollis per   Inceptos nulla maecenas curae libero','Morbi  ad','000000408'),
(142,'00000000000','0000000000000000000000000000','12120',0,464.00,464.00,'2020-11-16','ante natoque cursus  purus ultrices duis turpis facilisi nunc vel   quisque sociosqu eget blandit','Est conubia laoreet','000000525'),
(112,'00000000000','0000000000000000000000000000','2719',0,12.00,12.00,'2020-11-17','cubilia parturient  Eleifend dictumst cursus fringilla congue mi donec elementum  taciti malesuada  bibendum nisl','Suscipit augue luctus','000000435'),
(130,'00000000000','0000000000000000000000000000','1927',0,49.00,49.00,'2020-11-20','lacinia duis pretium augue dictum consectetur tempor cubilia  ante amet dapibus  habitant pellentesque iaculis blandit et  Eleifend','Non nostra quam','000000489'),
(72,'00000000000','0000000000000000000000000000','325135',0,12.00,12.00,'2020-11-23','duis litora placerat netus etiam suscipit aliquet mi aliquam   magnis leo dui augue natoque sagittis primis ad magna euismod','Pretium consectetur porta','000000315'),
(124,'00000000000','0000000000000000000000000000','401',0,103.00,103.00,'2020-11-25',' neque venenatis porta nostra ultricies facilisi elit  hendrerit  Bibendum iaculis','Suspendisse at donec','000000471'),
(83,'00000000000','0000000000000000000000000000','320',0,48.00,48.00,'2020-11-26','dapibus odio magnis sociosqu proin nibh morbi posuere nulla integer cursus nunc','Sapien pretium morbi','000000348'),
(62,'00000000000','0000000000000000000000000000','7806010',0,0.04,0.04,'2020-11-30','pulvinar lobortis lacus tellus mauris  Integer diam per cubilia risus class  nunc consectetur accumsan inceptos nascetur','Blandit adipiscing facilisi','000000285'),
(1,'00000000000','0000000000000000000000000000','7832003',2.50,0,2.50,'2020-11-30','  montes molestie accumsan sed dictumst dolor nec maecenas suspendisse malesuada imperdiet lorem  non conubia  consequat torquent ex sem mollis','Parturient finibus lectus','000000102'),
(97,'00000000000','0000000000000000000000000000','875',0,216.00,216.00,'2020-12-02',' platea maximus taciti consequat arcu sem turpis himenaeos odio ac   velit eleifend potenti','Lorem ipsum dolor','000000390'),
(111,'00000000000','0000000000000000000000000000','7910216',10.00,0,10.00,'2020-12-07','habitant semper cursus dictumst bibendum placerat  Tellus tempor semper pretium morbi  blandit adipiscing facilisi risus lacus ','Tempus viverra efficitur','000000432'),
(69,'00000000000','0000000000000000000000000000','23',470.00,0,470.00,'2020-12-09','id a eros rutrum magna vestibulum pulvinar quam  aliquam natoque torquent  proin dis vel platea ultrices  Suscipit elit magnis amet','Accumsan rhoncus lobortis','000000306'),
(24,'00000000000','0000000000000000000000000000','7939458',8.93,0,8.93,'2020-12-09','sapien quam phasellus venenatis volutpat  ac taciti egestas consequat semper ornare   Nec ut venenatis accumsan rhoncus lobortis tellus tincidunt pellentesque ','Pretium parturient ','000000171'),
(63,'00000000000','0000000000000000000000000000','725',0,55.00,55.00,'2020-12-09','nostra commodo dis eu cubilia tempus  interdum  Cursus phasellus nascetur leo pretium','Id a eros','000000288'),
(121,'00000000000','0000000000000000000000000000','36903',0,12.00,12.00,'2020-12-10','consectetur porta parturient  pulvinar ad lacus lacinia vivamus  elementum ullamcorper ','Tristique libero netus','000000462'),
(115,'00000000000','0000000000000000000000000000','1115',0,12.00,12.00,'2020-12-14','etiam dictumst elit rhoncus nullam netus  Convallis morbi tellus aenean ut justo','Ullamcorper taciti arcu','000000444'),
(20,'00000000000','0000000000000000000000000000','425',0,245.00,245.00,'2020-12-17','imperdiet  conubia orci  consequat pellentesque nisi ornare natoque iaculis accumsan finibus primis  habitant odio quam fusce  lacinia torquent faucibus','Rutrum aliquam per','000000159'),
(98,'00000000000','0000000000000000000000000000','256',0,24.00,24.00,'2020-12-18',' Nam odio porta litora magnis ornare pulvinar libero fusce  eget sed inceptos volutpat  quisque eros molestie scelerisque blandit  sagittis porttitor','Adipiscing  elit','000000393'),
(75,'00000000000','0000000000000000000000000000','679',0,28.00,28.00,'2020-12-21','euismod sapien pretium morbi lobortis  Erat vitae  tempor faucibus vestibulum efficitur netus sapien fames inceptos rhoncus conubia  ridiculus leo','Convallis morbi tellus','000000324'),
(31,'00000000000','0000000000000000000000000000','983',0,154.00,154.00,'2020-12-21','sagittis dignissim  ad risus venenatis hendrerit sollicitudin iaculis  nibh pellentesque sociosqu','Mauris primis suspendisse','000000192'),
(47,'00000000000','0000000000000000000000000000','24',470.00,0,470.00,'2020-12-23','bibendum viverra auctor in amet diam  habitasse  Dui euismod vitae mi condimentum','Magna euismod ','000000240'),
(154,'00000000000','0000000000000000000000000000','8018499',8.93,0,8.93,'2020-12-23','netus ut nostra curae lacus  risus eleifend etiam auctor diam','Rutrum proin malesuada','000000561'),
(138,'00000000000','0000000000000000000000000000','1359',0,155.00,155.00,'2020-12-24','nunc  bibendum curabitur purus et  ipsum arcu cursus integer malesuada','Proin  curae','000000513'),
(24,'00000000000','0000000000000000000000000000','13861',0,235.00,235.00,'2020-12-24','mauris finibus lorem  Laoreet eu sodales non  imperdiet mi massa condimentum risus molestie  neque dui per elit convallis nascetur eleifend ','Pretium parturient ','000000171'),
(115,'00000000000','0000000000000000000000000000','14183',0,498.00,498.00,'2020-12-24','Lorem ipsum dolor sit amet consectetur adipiscing  elit ultricies facilisi nibh sagittis leo  orci id volutpat rutrum  sollicitudin  Cursus','Ullamcorper taciti arcu','000000444'),
(17,'00000000000','0000000000000000000000000000','2341',0,12.00,12.00,'2020-12-28','imperdiet porta hac fermentum id risus primis suscipit natoque nibh leo  sodales litora sit morbi  ad libero per hendrerit porttitor quam','Potenti non ad','000000150'),
(165,'00000000000','0000000000000000000000000000','409',0,36.00,36.00,'2020-12-31',' tristique libero netus tellus velit  Efficitur augue tempus phasellus sodales amet','Varius praesent ','000000594'),
(21,'00000000000','0000000000000000000000000000','8077360',0,0.15,0.15,'2020-12-31','ultrices turpis  Magna sociosqu facilisis laoreet metus euismod natoque  odio ornare leo rutrum  tincidunt','Aptent facilisi placerat','000000162'),
(57,'00000000000','0000000000000000000000000000','1009',0,36.00,36.00,'2020-12-31','taciti arcu hac augue eros auctor phasellus scelerisque imperdiet maximus  ipsum netus fermentum magnis  vestibulum ad erat et','Accumsan inceptos nascetur','000000270'),
(4,'00000000000','0000000000000000000000000000','8103985',17.10,0,17.10,'2020-12-31','viverra efficitur lectus odio  suscipit augue luctus sapien sodales id mollis  venenatis ligula sed commodo ridiculus dictumst  Class adipiscing  ullamcorper','Suspendisse facilisis ','000000111'),
(52,'00000000000','0000000000000000000000000000','25',900.00,0,900.00,'2020-12-31','pellentesque class  taciti convallis aliquam magna fusce  tempor suscipit arcu  etiam auctor adipiscing purus per magnis posuere  Et varius tempus','Sed dictumst dolor','000000255'),
(37,'00000000000','0000000000000000000000000000','8099223',2.50,0,2.50,'2020-12-31','tellus dignissim  laoreet aptent lorem luctus blandit proin integer rhoncus  lacus pharetra  Lacus inceptos dolor consequat tellus eu dui','Turpis facilisi nunc','000000210'),
(16,'00000000000','0000000000000000000000000000','8173210',10.00,0,10.00,'2021-01-11','aenean commodo erat scelerisque  in habitasse suspendisse at donec  vehicula sociosqu praesent potenti  vel','Fusce consectetur ','000000147'),
(23,'00000000000','0000000000000000000000000000','23686',0,44.00,44.00,'2021-01-14','dignissim bibendum ornare curabitur facilisi quis lorem  Vivamus curae  imperdiet nisl sed maecenas sit cursus nunc aenean','Leo himenaeos a','000000168'),
(101,'00000000000','0000000000000000000000000000','23695',0,39.00,39.00,'2021-01-15','at  conubia taciti ut risus nascetur class primis facilisis','Hac fermentum id','000000402'),
(78,'00000000000','0000000000000000000000000000','35',0,82.00,82.00,'2021-01-20','amet   Non nostra quam magna accumsan habitasse dapibus morbi pellentesque  mollis orci tincidunt senectus libero','Primis  habitant','000000333'),
(66,'00000000000','0000000000000000000000000000','1',149.56,0,149.56,'2021-01-22','lorem  praesent ultrices nam  adipiscing ridiculus lobortis suspendisse eleifend facilisi vestibulum  Semper','Suscipit elit magnis','000000297'),
(23,'00000000000','0000000000000000000000000000','184',0,25.00,25.00,'2021-01-25','augue faucibus  posuere dictumst sem facilisi aenean pellentesque quis blandit  cras scelerisque sollicitudin','Leo himenaeos a','000000168'),
(115,'00000000000','0000000000000000000000000000','16',0,41.00,41.00,'2021-01-27','vel porttitor laoreet  cubilia luctus sociosqu proin  curae inceptos est vestibulum praesent','Ullamcorper taciti arcu','000000444'),
(13,'00000000000','0000000000000000000000000000','95',0,62.00,62.00,'2021-01-28','fusce parturient cursus integer  Litora lacus  interdum euismod etiam ut nam quisque vitae  dictum id est conubia laoreet nibh parturient lorem','Viverra feugiat dictum','000000138'),
(135,'00000000000','0000000000000000000000000000','139',0,295.00,295.00,'2021-01-28','metus  enim sed  sagittis convallis ornare vestibulum feugiat  Ut ornare cursus vestibulum facilisis','Posuere dictumst sem','000000504'),
(102,'00000000000','0000000000000000000000000000','8326367',2.50,0,2.50,'2021-01-29','dictum lectus vel ridiculus mus  sit per diam  tristique nullam nibh at litora rhoncus enim nisl scelerisque habitasse  Orci','Natoque nibh leo','000000405'),
(18,'00000000000','0000000000000000000000000000','8303751',0,0.05,0.05,'2021-01-29','vel sollicitudin sem  commodo eleifend sed eros inceptos dapibus vehicula sapien  mauris laoreet rhoncus elementum duis class facilisi ','Quisque montes ','000000153'),
(7,'00000000000','0000000000000000000000000000','1',470.00,0,470.00,'2021-02-01','maecenas habitant  Quam lacinia parturient etiam fusce eget egestas risus rutrum proin malesuada','Semper imperdiet ','000000120'),
(97,'00000000000','0000000000000000000000000000','8362815',8.93,0,8.93,'2021-02-01','ad  aenean id  fermentum sodales nisl donec porttitor luctus non  Cras euismod dis himenaeos blandit','Lorem ipsum dolor','000000390'),
(161,'00000000000','0000000000000000000000000000','8400391',10.00,0,10.00,'2021-02-04','cubilia netus ipsum nisi  turpis vehicula lacus  auctor proin placerat hac sapien duis facilisi accumsan','Molestie ac tellus','000000582'),
(81,'00000000000','0000000000000000000000000000','52',0,65.00,65.00,'2021-02-04','integer massa  litora ullamcorper  vulputate senectus molestie ac tellus urna erat enim  Convallis','Eget sed inceptos','000000342'),
(15,'00000000000','0000000000000000000000000000','48',0,24.00,24.00,'2021-02-04','molestie lacus vehicula netus pharetra hendrerit  lacinia tincidunt mauris  vel volutpat himenaeos sagittis porttitor bibendum varius praesent  et','Elit  himenaeos','000000144'),
(3,'00000000000','0000000000000000000000000000','26',0,30.00,30.00,'2021-02-05',' fames  maximus libero sollicitudin ac a hendrerit massa pellentesque mollis vehicula  parturient','A curae adipiscing','000000108'),
(56,'00000000000','0000000000000000000000000000','71',0,50.00,50.00,'2021-02-05','massa cras inceptos  interdum maecenas egestas eleifend  Justo feugiat elit cursus diam proin leo curabitur ligula lectus curae','Per cubilia risus','000000267'),
(9,'00000000000','0000000000000000000000000000','53',0,80.00,80.00,'2021-02-10','posuere facilisis metus  donec per non consectetur volutpat Platea luctus sodales phasellus maecenas fermentum tempor mus ','Laoreet vel mattis','000000126'),
(56,'00000000000','0000000000000000000000000000','211',0,12.00,12.00,'2021-02-10','bibendum efficitur  finibus interdum nec id  nulla rutrum molestie dis dapibus venenatis  Quam potenti etiam sem rutrum','Per cubilia risus','000000267'),
(75,'00000000000','0000000000000000000000000000','326',0,154.00,154.00,'2021-02-16','vitae consectetur  montes fermentum pharetra placerat pretium leo  hendrerit penatibus molestie nisi neque pulvinar purus porta','Convallis morbi tellus','000000324'),
(87,'00000000000','0000000000000000000000000000','133',0,183.00,183.00,'2021-02-18','laoreet  cursus  Lorem consectetur sagittis justo feugiat nunc hendrerit inceptos non volutpat quam  nisl in egestas porta  dolor','Hendrerit sollicitudin iaculis','000000360'),
(118,'00000000000','0000000000000000000000000000','2',400.00,0,400.00,'2021-02-24','imperdiet vel facilisi  Vitae venenatis amet himenaeos vel magna orci  eget cras conubia natoque tempor  ullamcorper laoreet  dignissim sit sagittis','Erat et ultrices','000000453'),
(52,'00000000000','0000000000000000000000000000','8503761',7.60,0,7.60,'2021-02-24','platea per  Iaculis efficitur pretium nulla per sed himenaeos id  rhoncus et  nullam ornare velit natoque purus','Sed dictumst dolor','000000255'),
(145,'00000000000','0000000000000000000000000000','8555844',2.50,0,2.50,'2021-02-26','congue primis penatibus pharetra  sit porttitor aliquet morbi  massa metus netus sem ','Vestibulum facilisis dictum','000000534'),
(153,'00000000000','0000000000000000000000000000','1162',0,195.00,195.00,'2021-02-26','A enim habitasse varius aptent hac ligula erat bibendum eleifend sodales lorem auctor  platea  etiam fringilla cras fames','Parturient etiam fusce','000000558'),
(145,'00000000000','0000000000000000000000000000','8541360',0,0.11,0.11,'2021-02-26','integer non tincidunt laoreet in facilisis litora  Mus netus aenean pulvinar','Vestibulum facilisis dictum','000000534'),
(20,'00000000000','0000000000000000000000000000','2',370.00,0,370.00,'2021-03-01',' arcu sollicitudin tellus dictum suspendisse  ad lobortis gravida congue sapien cursus ullamcorper','Rutrum aliquam per','000000159'),
(74,'00000000000','0000000000000000000000000000','8642270',3.07,0,3.07,'2021-03-04',' per consectetur  blandit penatibus lorem vehicula finibus  Torquent varius placerat felis viverra habitasse aptent adipiscing accumsan  himenaeos ','Etiam dictumst elit','000000321'),
(4,'00000000000','0000000000000000000000000000','8661728',6.93,0,6.93,'2021-03-09','magnis montes ac dapibus vel eget dignissim sagittis  ad','Suspendisse facilisis ','000000111'),
(8,'00000000000','0000000000000000000000000000','249',0,12.00,12.00,'2021-03-09','facilisi et habitant leo odio mollis tempus   Netus hac lectus egestas eleifend per justo nostra  quam primis leo fringilla ad et','Nulla hac mollis','000000123'),
(11,'00000000000','0000000000000000000000000000','89',0,94.00,94.00,'2021-03-15','quisque  quis arcu mauris  penatibus platea tortor  Est ac mollis bibendum felis suscipit odio natoque  non in luctus gravida','Non vestibulum ','000000132'),
(49,'00000000000','0000000000000000000000000000','222',0,110.00,110.00,'2021-03-18','Parturient finibus lectus vehicula nisl blandit dignissim eleifend tristique   habitant fermentum torquent a','Bibendum iaculis dapibus','000000246'),
(2,'00000000000','0000000000000000000000000000','642',0,12.00,12.00,'2021-03-23','curae adipiscing sed congue  suspendisse facilisis  himenaeos mi consectetur magnis dis  Auctor conubia bibendum varius sollicitudin  magna fermentum quis semper','Dignissim eleifend tristique','000000105'),
(151,'00000000000','0000000000000000000000000000','8739777',4.09,0,4.09,'2021-03-24',' Amet ipsum tempus non vestibulum  suscipit consectetur massa enim  imperdiet vulputate','Mauris laoreet rhoncus','000000552'),
(49,'00000000000','0000000000000000000000000000','3',215.00,0,215.00,'2021-03-24','imperdiet  sodales venenatis commodo nulla hac mollis  justo ac dictum  laoreet vel mattis nisl ut a et sed','Bibendum iaculis dapibus','000000246'),
(18,'00000000000','0000000000000000000000000000','23',0,39.00,39.00,'2021-03-26','eget risus viverra feugiat dictum urna id   torquent turpis orci phasellus porttitor justo elit  Himenaeos semper condimentum lorem fusce consectetur ','Quisque montes ','000000153');

GO

UPDATE Clients
SET UNP = Report.UNP
FROM Report
WHERE Report.UNP IS NOT NULL AND Clients.Id= Report.ClientID

GO


IF OBJECT_ID('newTable', 'U') IS NOT NULL
 BEGIN
    DROP TABLE newTable
END

IF OBJECT_ID('IncomeIds', 'U') IS NOT NULL
BEGIN
    DROP TABLE IncomeIds
END

DECLARE @LastDate DATE
DECLARE @FirstDate DATE

SELECT @LastDate = MAX(Income.[Date])
FROM Income

SELECT @FirstDate = MIN(Report.[date])
FROM Report

CREATE TABLE newTable(
ReportId INT
)

--
-- Insert into Income table
--
IF @FirstDate <= @LastDate
BEGIN
    SELECT ClientId,Number,Summ
    INTO IncomeIds
    FROM Income
    WHERE [Date] BETWEEN @FirstDate AND @LastDate

    INSERT INTO newTable(ReportId)
    SELECT Report.Id
    FROM Report
    WHERE(SELECT Id
        FROM IncomeIds
        WHERE Report.ClientId = ClientId
            AND Report.Number = Number
            AND Report.Credit = Summ) IS NOT NULL
END

INSERT INTO Income(ClientId, Summ, [Date], Number)
SELECT ClientId, Credit,[date],Number
FROM  Report
WHERE Report.Credit != 0 AND
    (SELECT ReportId
    FROM newTable
    WHERE Report.Id = ReportId) IS NULL


--
-- Insert into Expenses table
--
SELECT @LastDate = MAX(Expenses.[Date])
FROM Expenses

DELETE newTable

IF @FirstDate <= @LastDate
BEGIN
    SELECT Number,Summ,[Date]
    INTO ExpensesData
    FROM Expenses
    WHERE [Date] BETWEEN @FirstDate AND @LastDate

    INSERT INTO newTable(ReportId)
    SELECT Report.Id
    FROM Report
    WHERE(SELECT Id
        FROM ExpensesData
        WHERE Report.ClientId = ClientId
            AND Report.Number = Number
            AND Report.Credit = Summ
			AND Report.[date] = [Date]) IS NOT NULL
END

INSERT INTO Expenses(Summ, [Date], Number)
SELECT Debit,[date],Number
FROM  Report
WHERE  Report.Debit != 0 AND
	(SELECT ReportId
    FROM newTable
    WHERE Report.Id = ReportId) IS NULL

GO

DROP TABLE newTable
IF OBJECT_ID('IncomeIds', 'U') IS NOT NULL
BEGIN
    DROP TABLE IncomeIds
END

